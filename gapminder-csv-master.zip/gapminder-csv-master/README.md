# gapminder-csv

A single `gapminder.csv` dataset for all Gapminder datapoints, combined from [Gapminder's Systema Globalis](https://github.com/open-numbers/ddf--gapminder--systema_globalis). Documentation, metadata and lookup tables available at that repo.

Thanks to Jasper Heeffer and Angie Skazka for helping to access Gapminder's underlying data in a tidy format.
